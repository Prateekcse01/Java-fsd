package com.Create.Select.Drop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) {
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","Ramesh@123sangu");
            System.out.println("Connection successfully"); 
            Statement stmt = con.createStatement();
            System.out.println("Statement created... successfully");
            
            
            // create a databse 
             String createDatabase = ("create database newdb") ;
             stmt.executeUpdate(createDatabase);
             System.out.println("Database created successfully.");
         
            //select a newly created databse
            String useDatabase = (" use newdb");
            stmt.executeUpdate(useDatabase);
            System.out.println("Using Databse");
		    
           // drop databse 
            String dropDatabase = "DROP DATABASE newdb";
            stmt.executeUpdate(dropDatabase);
            System.out.println("Database dropped successfully.");
            
		}
            
            
            
            
            catch (Exception e){
            	System.out.print(e); 

            }   
		}

	}
