package com.Proccedure.ExcHandling;

import java.sql.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		try {

			// Driver Loader
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");

			// Connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Ramesh@123sangu");
			System.out.println("Connection successfully");

			Statement stmt = con.createStatement();

			Scanner scn = new Scanner(System.in);

			ResultSet rs = stmt.executeQuery("select *from employee");

			while (rs.next()) {
				System.out.println(
						" id is " + rs.getInt(1) + " Name is " + rs.getString(2) + " Salary is " + rs.getFloat(3));

			}

		} catch (Exception e) {
			System.out.print(e);

		}

	}

}