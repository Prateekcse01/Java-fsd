package com.Insert.Update.delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Ramesh@123sangu");
			System.out.println("Connection successfully");
			Statement stmt = con.createStatement();
			System.out.println("Statement created... successfully");

			// Insert record
			String insertQuery = (" insert into employee (id, name, salary) values (?, ?, ?)");
			try (PreparedStatement insertStatement = con.prepareStatement(insertQuery)) {

				insertStatement.setInt(1, 6);
				insertStatement.setString(2, "John Doe");
				insertStatement.setInt(3, 30000);
				int rowsInserted = insertStatement.executeUpdate();
				System.out.println(rowsInserted + " row(s) inserted.");

			}

			// Updation

			String updateQuery = "UPDATE employee SET Salary = ? WHERE id = ? AND name = ?";
			try (PreparedStatement updateStatement = con.prepareStatement(updateQuery)) {
				updateStatement.setInt(1, 35000);
				updateStatement.setInt(2, 7);
				updateStatement.setString(3, "John Doe");
				int rowsUpdated = updateStatement.executeUpdate();
				System.out.println(rowsUpdated + " row(s) updated.");
			}

			// Deletion

			String deleteQuery = "DELETE FROM employee WHERE id = ?";
			try (PreparedStatement deleteStatement = con.prepareStatement(deleteQuery)) {
				deleteStatement.setInt(1, 6);
				int rowsDeleted = deleteStatement.executeUpdate();
				System.out.println(rowsDeleted + " row(s) deleted.");
			}

		}

		catch (Exception e) {
			e.printStackTrace();

		}

	}

}
