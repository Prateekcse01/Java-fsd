package com.Connection.Statement.ResultSet;
import java.sql.*;

public class Main {

	public static void main(String[] args) {
		try {
			
			// Driver Loader
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loaded Successfully");
			
			//Connection 
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","Ramesh@123sangu");
			System.out.println("Connection successfully");
			
			// Statement
			Statement stmt = con.createStatement();
	        System.out.println("Statement created... successfully");
	        
	         int result = stmt.executeUpdate("insert into employee values(5,'Mahesh',34000)");
            if(result>0) {
            	System.out.println("Record is inserted successfully");
               }
           
             
			
		    }
		catch (Exception e){
			System.out.print(e); 
		
		}
	

	}
	
}
