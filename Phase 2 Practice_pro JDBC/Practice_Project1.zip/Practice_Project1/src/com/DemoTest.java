package com;
import java.sql.*;
import java.util.Scanner;
public class DemoTest {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//System.out.println("Driver Loaded Successfully");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","Ramesh@123sangu");
            //System.out.println("Connection successfully"); 
            Statement stmt = con.createStatement();
           // System.out.println("Statement created... successfully");
            
         /* Insert Query
          *
            int result = stmt.executeUpdate("insert into employee values(1,'Mahesh',45000)");
            if(result>0) {
            	System.out.println("Record is inserted successfully");
               }
            
            
            
            // Delete Query
            int result = stmt.executeUpdate("Delete from employee where id = 1 ");
            if(result>0) {
            	System.out.println("Record deleted successfully");
            }
            else {
            System.out.println("Record Not found");
          
            }
            
           */ 
            // Same code for update and retrive so we will write same code as we have written for Insert and Delete
            
            Scanner scn =  new Scanner(System.in);
            
            
            //Inser Query using prepareStatement 
            PreparedStatement pstmt = con.prepareStatement("insert into employee value(?,?,?)");
            System.out.println("Enter the Id");
            int id = scn.nextInt();
            pstmt.setInt(1,id);
            
            System.out.println("Enter the Nmae");
            String name = scn.next();
            pstmt.setString(2, name);
            
            System.out.println("Enter the Salary");
            float salary = scn.nextFloat();
            pstmt.setFloat(3, salary);
            
            
            int result = pstmt.executeUpdate();
            if(result>0) {
            	System.out.println("Recored inserted Successfully");
            	
            }
            else {
            }
            
           // use of ResultSet 
            
            ResultSet rs = stmt.executeQuery("select *from employee");
           
            while(rs.next()) {
            	System.out.println(" id is " + rs.getInt(1) + " Name is " + rs.getString(2) + " Salary is " + rs.getFloat(3));
            	
            }
            
            
		}
		catch (Exception e){
			System.out.print(e);    // toString method to display exception
		}
			
		}

}
