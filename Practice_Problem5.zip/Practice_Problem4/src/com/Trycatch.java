package com;

class Trycatch {
	  public static void main(String[] args) {

	    try {
	      int div = 5 / 0;
	      System.out.println(" code of try block");
	    }

	    catch (ArithmeticException e) {
	      System.out.println("ArithmeticException => " + e.getMessage());
	    }
	  }
	}