package com;

class Synchronization1{  
void printTable(int n){ 
   for(int i=1;i<=5;i++){  
     System.out.println(n*i);  
     try{  
      Thread.sleep(200);  
     }catch(Exception e){System.out.println(e);}  
   }  
  
 }  
}  
  
class MyThread1 extends Thread {
	Synchronization1 t;

	MyThread1(Synchronization1 t) {
		this.t = t;
	}

	public void run() {
		t.printTable(5);
	}

}

class MyThread2 extends Thread {
	Synchronization1 t;

	MyThread2(Synchronization1 t) {
		this.t = t;
	}

	public void run() {
		t.printTable(400);
	}
}

class Synchronization {
	public static void main(String args[]) {
		Synchronization1 obj = new Synchronization1();
		MyThread1 t1 = new MyThread1(obj);
		MyThread2 t2 = new MyThread2(obj);
		t1.start();
		t2.start();
	}
}
