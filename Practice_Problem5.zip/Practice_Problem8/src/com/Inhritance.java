package com;
class Programmer {  
	 float salary=40000;  
	}  
	class Inhritance extends Programmer{  
	 int bonus=10000;  
	 public static void main(String args[]){  
		 Inhritance p =new Inhritance();  
	   System.out.println("Programmer salary is:"+p.salary);  
	   System.out.println("Bonus of Programmer is:"+p.bonus);  
	}  
	}  
