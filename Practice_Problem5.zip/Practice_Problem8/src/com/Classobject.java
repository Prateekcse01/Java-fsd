package com;

class Lamp {
	  
	  boolean isOn;

	  
	  void turnOn() {
	    isOn = true;
	    System.out.println("Light on? " + isOn);

	  }

	  
	  void turnOff() {
	    isOn = false;
	    System.out.println("Light on? " + isOn);
	  }
	}

	class ClassObject {
	  public static void main(String[] args) {

	    
	    Lamp Bulb = new Lamp();
	    Lamp Tubelight = new Lamp();

	   
	    Bulb.turnOn();

	   
	    Tubelight.turnOff();
	  }
	}