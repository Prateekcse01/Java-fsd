package com;

class Exceptionhandling {
	  public static void main(String[] args) {
	    try {
	      
	      int div = 5 / 0;
	    }

	    catch (ArithmeticException e) {
	      System.out.println("ArithmeticException => " + e.getMessage());
	    }
	    
	    finally {
	      System.out.println("This is the finally block");
	    }
	  }
	}