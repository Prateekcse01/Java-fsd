package com;

class ExceptionInJava1 extends Exception  {  
    public ExceptionInJava1 (String str)   {  
        
        super(str);  
    }  
}  
    
 
 class TestCustomException1  
{  
  
   
    static void validate (int age) throws ExceptionInJava1{    
       if(age < 18){  
  
       
        throw new ExceptionInJava1("age is not valid to vote");    
    }  
       else {   
        System.out.println("welcome to vote");   
        }   
     }    
  
     
    public static void main(String args[])  
    {  
        try  
        {  
           
            validate(13);  
        }  
        catch (ExceptionInJava1 ex)  
        {  
            System.out.println("Caught the exception");  
    
           
            System.out.println("Exception occured: " + ex);  
        }  
  
        System.out.println("rest of the code...");    
    }  
}  