package com;

class WaitMethod1  
{   
  
    
    private static Object obj1 = new Object();   
  
    
    public static void main(String[] args)throws InterruptedException   
    {   
          
      
        Thread.sleep(3000);   
          
      
        System.out.println( Thread.currentThread().getName() + " Thread is woken after three second");   
          
      
        synchronized (obj1)    
        {   
           
            obj1.wait(3000);   
  
            System.out.println(obj1 + " Object is in waiting state and woken after 3 seconds");   
        }   
    }   
}  