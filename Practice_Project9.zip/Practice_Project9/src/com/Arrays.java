package com;
import java.util.*;

public class Arrays {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = scn.nextInt();
		
	     int arr1[] = new int[n];
	     for(int i=0; i<n; i++) {
	    	 arr1[i] = scn.nextInt();
	     
	     System.out.println( "After the printing\n" + arr1[i]);
	   }
	}
}
