package com;

import java.util.Scanner;  

class LinearSearch   
{  
  public static void main(String args[])  
  {  
    int c, n, search, array[];  
   
    Scanner scn = new Scanner(System.in);  
    System.out.println("Enter number of elements");  
    n = scn.nextInt();   
    array = new int[n];  
   
    for (c = 0; c < n; c++)  
      array[c] = scn.nextInt();  
   
    System.out.println("Enter value to find");  
    search = scn.nextInt();  
   
    for (c = 0; c < n; c++)  
    {  
      if (array[c] == search)    
      {  
         System.out.println(search + " is present at location " + (c + 1) + ".");  
          break;  
      }  
   }  
   if (c == n)  
      System.out.println(search + " isn't present in array.");  
  }  
}  