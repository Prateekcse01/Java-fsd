package com;

import java.io.File;  

import java.io.IOException;   
class CreateFile {  
            public static void main(String args[]) {  
            try {  
                     
                    File fO = new File("D:FileOperationExample.txt");   
                    if (fO.createNewFile()) {  
                               System.out.println("File : " + fO.getName() + " is created successfully.");  
                    } else {  
                               System.out.println("File is already exist");  
                    }  
                  } catch (IOException exception) {  
                           System.out.println("An unexpected error");  
                           exception.printStackTrace();  
               }   
     }  
}  