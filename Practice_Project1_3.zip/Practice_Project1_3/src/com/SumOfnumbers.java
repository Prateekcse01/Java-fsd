package com;
import java.util.*;
public class SumOfnumbers{
	
	public static int sum(int n) {
		  int sum =0;
		  for(int i=0;i<n-1;i++) {
			 sum =sum+i;
			  
		  }
		  return sum;
	}
	public class Main{
	
	public static void main(String args[]) {
		System.out.println("Enter a number");
		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		
		int ans = sum(n);
		System.out.println("Ans is "+ans);
	    
		
	}

 
	}
  }

