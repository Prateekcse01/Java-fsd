package com;

public class Constructor{
	
   void	display(){
		System.out.println("This is a Default constuctor");
	}
	
	
    public static void main(String[] args) {
		
    	Constructor obj = new Constructor();
		obj.display();
	  
	}
	
}
