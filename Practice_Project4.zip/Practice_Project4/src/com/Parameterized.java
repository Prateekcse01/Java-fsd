package com;

class Parameterized{  
    int id;  
    String name;  
                                            
    Parameterized(int i,String n){               //creating a parameterized constructor  
    id = i;  
    name = n;  
    }  
     
    void display(){System.out.println(id+" "+name);
    
    }  
   
    public static void main(String args[]){  
     
    	Parameterized s1 = new Parameterized(111,"Karan");  
    
      
    s1.display();  
     
   }  
}  