/**
 * 
 */
/**
 * 
 */
module Practice_Problem6 {
}