package com;

import java.util.*; 


public class Hashmap1 { 

	
	public static void main(String[] args) 
	{ 

		// Creating an empty HashMap 
		Map<String, Integer> map = new HashMap<>(); 

		map.put("Ramu", 10); 
		map.put("Shyamu", 20); 
		map.put("Ankit", 30); 

		 
		for (Map.Entry<String, Integer> e : map.entrySet()) 

		
			System.out.println(e.getKey() + " " + e.getValue() + "  years old"); 
	} 
}

