package com;
 
import java.util.*; 


public class TreeMap2{ 

	
	public static void main(String[] args) 
	{ 

		// Creating an empty TreeMap 
		Map<String, Integer> map = new TreeMap<>(); 

		
		map.put("ramu", 10); 
		map.put("Shyamu", 50); 
		map.put("Ankit", 90); 

		
		for (Map.Entry<String, Integer> e : map.entrySet()) 

			
			System.out.println(e.getKey() + " " + e.getValue()+ " years old"); 
	} 
}

