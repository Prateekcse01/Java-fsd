/**
 * 
 */
/**
 * 
 */
module OperationinStack {
}