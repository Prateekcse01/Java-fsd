package com;

import java.util.Stack;

class OperationInStack {
	public static void main(String[] args) {

		Stack<String> St = new Stack<>();

		St.push("Hello");
		St.push("Hii");
		St.push("Wish you happy birthday");
		System.out.println("Stack: "+St);

		St.pop();
		System.out.println("After pop Operation: "+ St);
	}
}
