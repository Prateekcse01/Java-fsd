package com;

public class stringBuilder{
	 
    public static void main(String[] args) {
        
        String str = " convert String to StringBuilder";
        
        
        
        StringBuffer sbl = new StringBuffer(str);
        System.out.println("StringBuilder contents: " + sbl);
        
    }
    
    
}