package com;

public class StringBuffer1{
	 
    public static void main(String[] args) {
        
        String str = " convert String to StringBuffer";
        
        
        
        StringBuffer sbl = new StringBuffer(str);
        System.out.println("StringBuffer contents: " + sbl);
        
    }
    
    
}
