package com;

public class Employee {

	public Employee() {
		System.out.println("Object Created...using empty...");
	}
	
}
