package com;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao{
    private JdbcTemplate jdbcTemplate;

    @Autowired
    DataSource ds;
   
    public int storeEmployee(Employee employees) {
    	try  {
    		Connection con = ds.getConnection();
    		PreparedStatement pstmt = con.prepareStatement("insert into employees values(?,?,?)");
    		pstmt.setInt(1,employees.getId());
    		pstmt.setString(2,employees.getName());
    		pstmt.setInt(3,employees.getAge());
    		return pstmt.executeUpdate();
    	
    	} 
    	catch(Exception e) {
    		System.err.println(e);
    		return 0;
    		
    	}
       
    }

}
