package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	
		//ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
       // EmployeeDao employeeDAO = (EmployeeDao) context.getBean("employeeDAO");
       
		
@Autowired
EmployeeDao employeeDao;
		
		public String storeEmployee(Employee employee) {
			if(employeeDao.storeEmployee(employee)>0) {
				return "employee record stored successfully";
			}
			else {
				return "employee recored didn't store";
				
				
			}
		}

}
