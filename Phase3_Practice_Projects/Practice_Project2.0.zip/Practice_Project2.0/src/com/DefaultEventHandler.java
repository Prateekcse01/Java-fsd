package com;

import javax.swing.*;
import java.awt.event.*;

public class DefaultEventHandler {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Default Event Handling");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new JButton("Click Me");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Button clicked (Default Event Handling)");
            }
        });

        frame.getContentPane().add(button);
        frame.pack();
        frame.setVisible(true);
    }
}
