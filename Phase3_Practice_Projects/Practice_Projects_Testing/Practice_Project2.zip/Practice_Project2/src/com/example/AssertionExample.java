package com.example;

public class AssertionExample {
	
	public static void main(String[] args) {
        int x = 5;
        int y = 7;

      
        assert x < y : "Assertion failed: x is not less than y";

        
        assertNumbers(x, y);

        System.out.println("Program execution continues after assertions");
    }

    private static void assertNumbers(int x, int y) {
        assert x > 0 : "Assertion failed: x is not greater than 0";
        assert y % 2 == 0 : "Assertion failed: y is not an even number";
        System.out.println("Both assertions passed successfully");
    }
}

