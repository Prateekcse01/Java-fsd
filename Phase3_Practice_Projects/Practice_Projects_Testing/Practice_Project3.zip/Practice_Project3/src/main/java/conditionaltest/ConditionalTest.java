package conditionaltest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

public class ConditionalTest {

    @Test
    @EnabledIfSystemProperty(named = "environment", matches = "production")
    void runInProductionEnvironment() {
        System.out.println("Running in production environment");
    }

    @Test
    @EnabledIfSystemProperty(named = "java.version", matches = "11.*")
    void runOnJava11() {
        System.out.println("Running on Java 11");
    }

    @Test
    @DisabledIfSystemProperty(named = "skip.tests", matches = "true")
    void disableIfSkipTestsIsTrue() {
        System.out.println("This test is disabled if skip.tests is true");
    }
}
