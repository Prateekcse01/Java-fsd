package com.dyanmic.test;
       import java.util.Arrays;
	   import java.util.Collection;
	   
	   import static org.junit.jupiter.api.Assertions.assertEquals;
	   import static org.junit.jupiter.api.DynamicTest.dynamicTest;

	   public class DynamicTestsDemo {

	       @TestFactory
	       Collection<DynamicTestsDemo> dynamicTests() {
	           // Collection of test cases
	           return Arrays.asList(
	                   dynamicTests("Test Addition", () -> assertEquals(4, add(2, 2))),
	                   dynamicTests("Test Subtraction", () -> assertEquals(2, subtract(4, 2))),
	                   dynamicTests("Test Multiplication", () -> assertEquals(8, multiply(4, 2))),
	                   dynamicTests("Test Division", () -> assertEquals(2, divide(4, 2)))
	           );
	       }

	       int add(int a, int b) {
	           return a + b;
	       }

	       int subtract(int a, int b) {
	           return a - b;
	       }

	       int multiply(int a, int b) {
	           return a * b;
	       }

	       int divide(int a, int b) {
	           return a / b;
	       }
	   }

