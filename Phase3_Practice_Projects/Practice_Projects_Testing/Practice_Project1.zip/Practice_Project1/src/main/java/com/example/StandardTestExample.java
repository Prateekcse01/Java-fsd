package com.example;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class StandardTestExample {

    @Test
    void additionTest() {
        int result = Calculator.add(3, 5);
        Assertions.assertEquals(8, result, "3 + 5 should equal 8");
    }

    @Test
    void subtractionTest() {
        int result = Calculator.subtract(10, 4);
        Assertions.assertEquals(6, result, "10 - 4 should equal 6");
    }

    @Test
    void multiplicationTest() {
        int result = Calculator.multiply(2, 7);
        Assertions.assertEquals(14, result, "2 * 7 should equal 14");
    }

    @Test
    void divisionTest() {
        double result = Calculator.divide(20, 5);
        Assertions.assertEquals(4.0, result, "20 / 5 should equal 4.0");
    }
}

