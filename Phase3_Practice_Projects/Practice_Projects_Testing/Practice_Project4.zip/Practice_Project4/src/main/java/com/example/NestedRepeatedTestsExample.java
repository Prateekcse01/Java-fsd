package com.example;

import org.junit.jupiter.api.*;

class NestedRepeatedTestsExample {

    @Nested
    @DisplayName("Nested Test Group 1")
    class NestedTestGroup1 {

        @Test
        @DisplayName("Nested Test 1")
        void nestedTest1() {
            System.out.println("Running Nested Test 1");
            Assertions.assertTrue(true);
        }

        @RepeatedTest(value = 3, name = "Repeated Test {currentRepetition}/{totalRepetitions}")
        @DisplayName("Repeated Test")
        void repeatedTest() {
            System.out.println("Running Repeated Test");
            Assertions.assertNotEquals(0, Math.random());
        }
    }

    @Nested
    @DisplayName("Nested Test Group 2")
    class NestedTestGroup2 {

        @Test
        @DisplayName("Nested Test 2")
        void nestedTest2() {
            System.out.println("Running Nested Test 2");
            Assertions.assertFalse(false);
        }
    }

    @Test
    @DisplayName("Simple Test")
    void simpleTest() {
        System.out.println("Running Simple Test");
        Assertions.assertNotNull(new Object());
    }
}
