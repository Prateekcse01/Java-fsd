package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
		
		
	//	@Component                                // <bean class="com.Employee"></bean>
		public class Employee {                     // id is employee
			private int id;
		//	@Value(value = "Ravi")
			private String name;
		//	@Value(value = "34000")
			private float salary;
			private Address add;                // Employee has a address
			
			public Employee() {
				System.out.println("Object Created...using empty...");
			}
			
			
			public Address getAdd() {
				return add;
			}


			public void setAdd(Address add) {
				this.add = add;
			}


			public Employee(int id, String name, float salary) {
				System.out.println("Object created.. using parameters..");
				this.id = id;
				this.name = name;
				this.salary = salary;
			}


			public int getId() {
				return id;
			}


			public void setId(int id) {
				this.id = id;
			}


			public String getName() {
				return name;
			}


			public void setName(String name) {
				this.name = name;
			}


			public float getSalary() {
				return salary;
			}


			public void setSalary(float salary) {
				this.salary = salary;
			}


			public void display() {
				System.out.println("This is display method inside employee class");
			}

			@Override
			public String toString() {
				return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", add=" + add + "]";
			}
			
		}
		
			
		
		