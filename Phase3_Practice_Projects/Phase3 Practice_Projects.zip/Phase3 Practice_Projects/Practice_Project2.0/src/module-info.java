/**
 * 
 */
/**
 * 
 */
module Practice_Project1 {
	requires java.desktop;
}