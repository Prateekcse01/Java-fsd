package com;

import java.util.*;

class CustomEvent extends EventObject {
 public CustomEvent(Object source) {
     super(source);
 }
}


interface CustomEventListener {
 void handleCustomEvent(CustomEvent event);
}


class EventGenerator {
 private List<CustomEventListener> listeners = new ArrayList<>();

 public void addCustomEventListener(CustomEventListener listener) {
     listeners.add(listener);
 }

 public void performAction() {
    
     System.out.println("----Action performed --->(Custom Event Handling)");

   
     CustomEvent event = new CustomEvent(this);
     for (CustomEventListener listener : listeners) {
         listener.handleCustomEvent(event);
     }
 }
}


class CustomEventHandler implements CustomEventListener {
 public void handleCustomEvent(CustomEvent event) {
     System.out.println("----Custom event handled----");
 }
}

public class CustomEventHandlerDemo {
 public static void main(String[] args) {
     EventGenerator generator = new EventGenerator();
     CustomEventHandler handler = new CustomEventHandler();

     
     generator.addCustomEventListener(handler);

     generator.performAction();
 }
}
