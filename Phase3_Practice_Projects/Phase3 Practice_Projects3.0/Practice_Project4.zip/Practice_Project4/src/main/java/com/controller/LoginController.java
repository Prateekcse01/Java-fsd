package com.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {
	
	@RequestMapping(value = "/")                 //   http://localhost:9090
	public String openFeedbackform() {
		return "feedback";
		
	}
	
	@RequestMapping(value = "/submitFeedback", method = RequestMethod.POST )
	public String checkFeedback(HttpServletRequest req) {
		String name = req.getParameter("name");
		String comments = req.getParameter("comment");
	//	System.out.println(name);
		//System.out.println(comments);
		return "success";
		
		
		
	}

}
