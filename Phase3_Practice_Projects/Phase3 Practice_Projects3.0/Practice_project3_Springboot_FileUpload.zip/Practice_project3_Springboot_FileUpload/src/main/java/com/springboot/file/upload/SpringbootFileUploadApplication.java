package com.springboot.file.upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootFileUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootFileUploadApplication.class, args);
	}

}
