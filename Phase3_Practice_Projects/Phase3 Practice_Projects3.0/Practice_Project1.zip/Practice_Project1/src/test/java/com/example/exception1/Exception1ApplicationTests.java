package com.example.exception1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exception1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
