package com.example.exception1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/{id}")
    public ResponseEntity<String> getBookById(@PathVariable Long id) {
        if (id == null) {
            throw new CustomValidationException("ID cannot be null.");
        }

       
        String bookData = bookService.getBookDataById(id);

        if (bookData == null) {
            throw new CustomNotFoundException("Book not found for ID: " + id);
        }

        return ResponseEntity.ok(bookData);
    }
}
