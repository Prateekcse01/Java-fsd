package com.example.exception1;

import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl implements BookService {
	
	@Override
    public String getBookDataById(Long id) {
        
        if (id == 1) {
            return "Book Title: Sample Book, Author: John Doe";
        } else {
            return null;
        }
    }

}
