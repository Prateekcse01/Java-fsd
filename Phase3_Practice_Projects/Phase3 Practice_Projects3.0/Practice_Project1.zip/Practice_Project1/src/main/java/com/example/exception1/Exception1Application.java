package com.example.exception1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exception1Application {

	public static void main(String[] args) {
		SpringApplication.run(Exception1Application.class, args);
		
		
	}

}
