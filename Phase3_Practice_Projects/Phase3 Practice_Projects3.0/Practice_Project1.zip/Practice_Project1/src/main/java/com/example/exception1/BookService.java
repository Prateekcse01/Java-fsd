package com.example.exception1;

public interface BookService {
	
	public String getBookDataById(Long id);
	   

}
