package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSpring {

	public static void main(String[] args) {
		SpringApplication.run(SimpleSpring.class, args); //start spring boot application
			 System.out.print("Spring boot up...");         
			
		}

	}


