package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	
	  @RequestMapping(value="/")                        //  http://localhost:8080/
	  public String openIndex() {
		  System.out.println("I came here in index");
		  return "index";                               // this is your file Name without extension
		  
	  }
	
	  
	  @RequestMapping(value="/hi")                        //  http://localhost:8080/
	  public String hiPage() {
		  System.out.println("I came here in hi Path");
		  return "hiPage";                                    // this is your file Name without extension
		  
	  }
	  
	  
	  @RequestMapping(value="/hello")                        //  http://localhost:8080/
	  public String helloPage() {
		  System.out.println("I came here in hello Path");
		  return "helloPage";                               // this is your file Name without extension
		  
	  }
	
	

}
