package com;

import java.util.*;  
public class stack1{  
	public static void main(String args[]){ 
		
		Stack<String> stack = new Stack<String>();  
		stack.push("hii");  
		stack.push("hello");  
		stack.push("Ramu");    
		stack.push("Ankit");  
		stack.pop(); 
		
		Iterator<String> itr=stack.iterator();  
		while(itr.hasNext()){  
			System.out.println(itr.next());  
		}  
	}  
}  