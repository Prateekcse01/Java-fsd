package com;

import java.util.*;  
class Array_List{ 
	
   public static void main(String args[]){ 
	   
ArrayList<String> list=new ArrayList<String>(); 

  list.add("Ramu");  
  list.add("Shyamu");  
  list.add("Ankit");  
  list.add("Ajay");  
 
Iterator itr=list.iterator();  
while(itr.hasNext()){  
System.out.println(itr.next());  
}  
}  
}  