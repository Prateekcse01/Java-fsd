package com;

import java.util.*;  
public class Linked_List{
	
   public static void main(String args[]){ 
	
      LinkedList<String> al=new LinkedList<String>();  
      
       al.add("Ramu");  
       al.add("Shyamu");  
       al.add("Ankit");  
       al.add("Ajay"); 
       
       Iterator<String> itr=al.iterator();  
         while(itr.hasNext()){  
            System.out.println(itr.next());  
      }  
   }  
}  