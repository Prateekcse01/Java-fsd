package com;


import java.util.Arrays;
import java.util.Collections;

class FourthSmallestInList{
	static int count(int[] nums, int mid)
	{
		
		int count1 = 0;

		for (int i = 0; i < nums.length; i++)
			if (nums[i] <= mid)
				count1++;

		return count1;
	}

	static int kthSmallest(int[] nums, int k)
	{
		int low = Integer.MAX_VALUE;
		int high = Integer.MIN_VALUE;
		
		for (int i = 0; i < nums.length; i++) {
			low = Math.min(low, nums[i]);
			high = Math.max(high, nums[i]);
		}
		
		while (low < high) {
			int mid = low + (high - low) / 2;
			
			if (count(nums, mid) < k)
				low = mid + 1;

			else
				high = mid;
		}

		return low;
	}

	
	public static void main(String[] args)
	{
		int arr[] = { 12, 14, 15, 18, 21, 23 };
		int k = 4;

	
		System.out.print("4th smallest element is "
						+ kthSmallest(arr, k));
	}
}



