package com.sessionTracking.cookies;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

// @WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		
		        response.setContentType("text/html");
		        PrintWriter out = response.getWriter();

		        // Get or create a cookie for the session
		        Cookie[] cookies = request.getCookies();
		        Cookie sessionCookie = null;
		        if (cookies != null) {
		            for (Cookie cookie : cookies){
		                if (cookie.getName().equals("sessionid")){
		                    sessionCookie = cookie;
		                    break;
		                }
		            }
		        }
		        if (sessionCookie == null) {
		            sessionCookie = new Cookie("sessionid", "123"); // You can use a unique value here
		            sessionCookie.setMaxAge(60 * 60 * 24); // Set the cookie's expiration time (in seconds)
		            response.addCookie(sessionCookie);
		        }

		        out.println("<html><head><title>Session Tracking using Cookies</title></head><body>");
		        out.println("<h3>Session Tracking using Cookies</h3>");
		        out.println("<p>Session ID: " + sessionCookie.getValue() + "</p>");
		        out.println("</body></html>");
	}

}
