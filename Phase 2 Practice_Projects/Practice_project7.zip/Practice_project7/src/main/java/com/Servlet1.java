package com;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

// @WebServlet("/servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String name = request.getParameter("nm");
		 
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 out.print("<h3> Name : " + name + " </h3>");
		 out.print("<a href ='ResponseServlet2?username = "+ name +"'>Servlet 2</a>");
	}

}
