package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class GenericServlet
 */
public class GenericServlet extends jakarta.servlet.GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see jakarta.servlet.GenericServlet#jakarta.servlet.GenericServlet()
     */
    public GenericServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>Hellow world ....<br>");
		out.println("This is generic Servlet</body></html>");
		
		out.close();
	}

}
