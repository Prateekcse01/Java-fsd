package com;

import jakarta.servlet.ServletException;

// import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class DogetPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DogetPost() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("----- Wellcome to servlet Application ---> On Console");
		PrintWriter out = response.getWriter();
		out.println("--- Wellcome to servlet Application ---> On Server or Browser"); // On Browser
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
