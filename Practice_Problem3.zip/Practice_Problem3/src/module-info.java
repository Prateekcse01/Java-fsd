/**
 * 
 */
/**
 * 
 */
module Practice_Problem3 {
}