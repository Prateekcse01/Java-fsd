package com;

class Queue {

	private static int front, rear, capacity;
	private static int queue[];

	Queue(int size) {
		front = rear = 0;
		capacity = size;
		queue = new int[capacity];
	}

	static void queueEnqueue(int item) {

		if (capacity == rear) {
			System.out.printf("\nQueue is full\n");
			return;
		}

		else {
			queue[rear] = item;
			rear++;
		}
		return;
	}

	static void queueDequeue() {

		if (front == rear) {
			System.out.printf("\nQueue is empty\n");
			return;
		}

		else {
			for (int i = 0; i < rear - 1; i++) {
				queue[i] = queue[i + 1];
			}

			if (rear < capacity)
				queue[rear] = 0;

			rear--;
		}
		return;
	}

	static void queueDisplay() {
		int i;
		if (front == rear) {
			System.out.printf("Queue is Empty\n");
			return;
		}

		for (i = front; i < rear; i++) {
			System.out.printf(" %d , ", queue[i]);
		}
		return;
	}

	public class QueueOperation {
		public static void main(String[] args) {

			Queue q = new Queue(4);

			System.out.println("Initial Queue:");

			q.queueDisplay();

			q.queueEnqueue(11);
			q.queueEnqueue(12);
			q.queueEnqueue(13);
			q.queueEnqueue(14);

			System.out.println("Queue after Enqueue Operation:");
			q.queueDisplay();

			q.queueEnqueue(14);

			q.queueDisplay();

			q.queueDequeue();
			q.queueDequeue();
			System.out.printf("\nQueue after two dequeue operations:");

			q.queueDisplay();

		}
	}
}