package com;
	 class Main{
		   
		 private String name;
		 
		 public String getName() {
		        return this.name;
		 }
		        
		 public void setName(String name) {
		            this.name= name;       
		 }
		 
	 }

	   public class PrivateModi{

		public static void main(String[] args) {
		  
		    Main d = new Main();
		    d.setName("Hellow");
		    System.out.println(d.getName());
		    
		}
	}