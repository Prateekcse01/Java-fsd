package com;

    class A{
		    // public variable
		    public int legCount;

		    // public method
		    public void display() {
		        System.out.println("I am an Dog ");
		        System.out.println("I have " + legCount + " legs.");
		    }
		}

		
         public class Public_Modi{
		    public static void main( String[] args ) {
		      
		        A obj = new A();
		        obj.legCount = 4;
		        obj.display();
		    }
		}
