package com;

public class Protected_modi {

	public static void main(String[] args) {
		

	}

}
