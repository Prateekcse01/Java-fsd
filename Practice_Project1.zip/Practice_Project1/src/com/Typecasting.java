package com;

public class Typecasting{

	public static void main(String[] args) {
		
		//  implicit type casting
		    int num = 10;
		    System.out.println("The integer value: " + num);

		    double data = num;
		    System.out.println("The double value: " + data);
		    
		// explicit type casting
		    
		    
		    double num1 = 10.99;
		    System.out.println("The double value: " + num1);

		 
		    int data1 = (int)num;
		    System.out.println("The integer value: " + data1);
		  }

}


