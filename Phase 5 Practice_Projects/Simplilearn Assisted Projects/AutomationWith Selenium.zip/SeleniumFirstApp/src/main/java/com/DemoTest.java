package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class DemoTest {

	public static void main(String[] args) throws Exception{
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("http://www.google.com");
		String title = driver.getTitle();
		System.out.println(title);
		
		String url = driver.getCurrentUrl();
		String data = driver.getPageSource();
		System.out.println(title);
		System.out.println(url);
		System.out.println(data);
		//driver.close();

	}

}
