package com.service;

public class Operation {

	public int add(int x, int y) {
		int sum = x+y;
		return sum;
		
	}
	
	public int sub(int x, int y) {
		int sub = x+y;
		return sub;
		
	}

}
