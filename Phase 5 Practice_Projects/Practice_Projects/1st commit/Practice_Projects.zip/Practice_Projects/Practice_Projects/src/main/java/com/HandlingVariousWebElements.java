package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingVariousWebElements {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("file:///F:/Phase4/Form/Project2.html");
		
		 WebElement usernameInput = driver.findElement(By.id("username"));
	        usernameInput.sendKeys("yourUsername");

	        WebElement passwordInput = driver.findElement(By.id("password"));
	        passwordInput.sendKeys("yourPassword");

	        WebElement checkbox = driver.findElement(By.id("checkboxId"));
	        checkbox.click();

	        WebElement radioButton = driver.findElement(By.id("radioButtonId"));
	        radioButton.click();

	        Select dropdown = new Select(driver.findElement(By.id("dropdownId")));
	        dropdown.selectByVisibleText("Option 2");

	        WebElement fileInput = driver.findElement(By.id("fileInputId"));
	        fileInput.sendKeys("D:\\Youtube Videos");

	        WebElement submitButton = driver.findElement(By.cssSelector("input[type='submit']"));
	        submitButton.click();

	        // Wait for a few seconds to observe any changes
	        try {
	            Thread.sleep(5000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Close the browser
	        //driver.quit();
	    }
	

	}


