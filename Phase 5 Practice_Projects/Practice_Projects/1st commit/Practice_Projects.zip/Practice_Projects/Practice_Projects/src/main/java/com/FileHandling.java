package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;



public class FileHandling {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("file:///F:/Phase4/Form/Project3.html");
		
		WebElement fileInput = driver.findElement(By.id("file-upload"));

        // Enter the file path into the file input element
        String filePath = "D:\\Youtube Videos";
        fileInput.sendKeys(filePath);
        WebElement form = driver.findElement(By.tagName("form"));
        form.submit();

       // driver.quit();
	}

}
