package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class WebElements {

	public static void main(String[] args) {
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("file:///F:/Phase4/Form/Project1.html");
		
		 WebElement usernameById = driver.findElement(By.id("username"));
	        usernameById.sendKeys("usernameById");

	        WebElement usernameByName = driver.findElement(By.name("username"));
	        usernameByName.sendKeys("usernameByName");

	        WebElement usernameByCssSelector = driver.findElement(By.cssSelector("input#username"));
	        usernameByCssSelector.sendKeys("usernameByCssSelector");

	        WebElement passwordById = driver.findElement(By.id("password"));
	        passwordById.sendKeys("passwordById");

	        WebElement passwordByName = driver.findElement(By.name("password"));
	        passwordByName.sendKeys("passwordByName");

	        WebElement passwordByCssSelector = driver.findElement(By.cssSelector("input#password"));
	        passwordByCssSelector.sendKeys("passwordByCssSelector");

	        // Submit the form
	        WebElement submitButton = driver.findElement(By.cssSelector("input[type='submit']"));
	        submitButton.click();

	        // Wait for a few seconds to observe the changes
	        try {
	            Thread.sleep(9000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Close the browser
	        //driver.quit();
	    }
	

	}


