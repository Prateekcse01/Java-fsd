package com;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ScreenShots {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("file:///F:/Phase4/Form/Project2.html");
		
		
		 File screenshotFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

	        try {
	           
	        	 File destinationFile = new File("screenshot.png");
	        	 java.nio.file.Files.copy(screenshotFile.toPath(), destinationFile.toPath());
	            System.out.println("Screenshot captured and saved successfully.");
	        } 
	        
	        catch (IOException e) {
	            System.err.println("Failed to capture screenshot: " + e.getMessage());
	        }

	       
	        //driver.quit();

	}

}
