package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class CssAndXPath {
	public static void main(String[] args) throws Exception {
		
		
		System.setProperty("webdriver.edge.driver","C:\\Users\\prate\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		System.out.println("Driver Loaded Successfully");
		
		WebDriver driver = new EdgeDriver();
		driver.get("file:///F:/Phase4/Form/Project1.html");
		
		
		 WebElement usernameInputById = driver.findElement(By.id("username"));
	        usernameInputById.sendKeys("yourUsername");

	        WebElement passwordInputById = driver.findElement(By.id("password"));
	        passwordInputById.sendKeys("yourPassword");

	        WebElement submitButtonByCss = driver.findElement(By.cssSelector("input[type='submit']"));
	        submitButtonByCss.click();

	        // Using XPath expressions
	        WebElement usernameInputByXpath = driver.findElement(By.xpath("//input[@id='username']"));
	        usernameInputByXpath.clear();
	        usernameInputByXpath.sendKeys("yourNewUsername");

	        WebElement passwordInputByXpath = driver.findElement(By.xpath("//input[@id='password']"));
	        passwordInputByXpath.clear();
	        passwordInputByXpath.sendKeys("yourNewPassword");

	        WebElement submitButtonByXpath = driver.findElement(By.xpath("//input[@type='submit']"));
	        submitButtonByXpath.click();

	        // Wait for a few seconds to observe any changes
	        try {
	            Thread.sleep(5000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Close the browser
	         //driver.quit();
	    }
	
	}


