package com;

public class Methods{
     //    static method  
	static void showStatic()   
	{  
	System.out.println("The static method is here.");  
	}  
	 
	void displayNonStatic()   
	{  
	System.out.println("Non-static method here.");  
	}  
	public static void main(String[] args)   
	{  
	  
	showStatic(); //called method  
	  
	Methods me=new Methods();  
	//calling non-static method  
	me.displayNonStatic(); //called method  
	}  
	}  