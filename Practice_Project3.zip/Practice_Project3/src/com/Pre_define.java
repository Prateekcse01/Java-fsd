package com;

public class Pre_define{   

public static void main(String[] args)   
{  
int a =3;
int b =5;
System.out.print("The max number is: " + Math.max(a,b));  
}  
}  
