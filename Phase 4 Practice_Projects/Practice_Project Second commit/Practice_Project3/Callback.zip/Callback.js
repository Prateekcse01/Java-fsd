
function fetchData(callback) {
    console.log("Fetching data...");

   
    setTimeout(function () {
        var data = { name: "Ravi", age: 35};
        console.log("Data fetched successfully!");
        
        
        callback(data);
    }, 2000);
}


function processData(data) {
    console.log("Processing data:", data.name + ", Age: " + data.age);
}


fetchData(processData);

