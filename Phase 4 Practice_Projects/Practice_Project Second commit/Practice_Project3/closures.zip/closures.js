function outerFunction() {
    var outerVariable = "I am from OuterFunction";

    function innerFunction() {
        console.log(outerVariable);
    }

    return innerFunction;
}


var closure = outerFunction();


closure();
