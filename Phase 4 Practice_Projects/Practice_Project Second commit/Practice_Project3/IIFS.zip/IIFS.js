(function () {
  
    function square(num) {
        return num * num;
    }

    
    var number = 5;
    var result = square(number);

    
    console.log("The square of", number, "is", result);
})();

