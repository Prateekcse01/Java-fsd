
function doSomethingAsync(callback) {
    setTimeout(function () {
        console.log("Task completed!");
        callback();
    }, 1000);
}


function onTaskCompleted() {
    console.log("Callback executed!");
}


doSomethingAsync(onTaskCompleted);
