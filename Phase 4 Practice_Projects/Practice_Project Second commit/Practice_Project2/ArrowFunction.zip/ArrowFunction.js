
const multiply = (a, b) => a * b;


const product = multiply(4, 6);
console.log(product); 
