var add = function (a, b) {
    return a + b;
};


var result = add(3, 5);
console.log(result);