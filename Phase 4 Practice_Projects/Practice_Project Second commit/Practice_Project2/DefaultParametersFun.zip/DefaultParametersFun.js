function power(base, exponent = 2) {
    return Math.pow(base, exponent);
}


console.log(power(3));      
console.log(power(2, 3)); 