
function sum(...numbers) {
    return numbers.reduce((total, num) => total + num, 0);
}

// Function call
console.log(sum(1, 2, 3, 4, 5)); // Output: 15
