

class Student extends Person {
    constructor(name, age, studentId) {
       
        super(name, age);
        this.studentId = studentId;
    }

    
    sayHello() {
        console.log(`Hello, I'm ${this.name}, a student with ID ${this.studentId}.`);
    }
}


let student = new Student('Alice', 20, 'S12345');


student.sayHello(); 
