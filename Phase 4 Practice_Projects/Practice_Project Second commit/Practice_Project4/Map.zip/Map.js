// Creating a Map
let myMap = new Map();


myMap.set('name', 'John');
myMap.set(42, 'Answer to the Ultimate Question');
myMap.set(true, 'Boolean value');


console.log(myMap.get('name'));  
console.log(myMap.get(42));      
console.log(myMap.get(true));    


console.log(myMap.has('age'));   


myMap.delete(42);


for (let [key, value] of myMap) {
    console.log(key + ' -> ' + value);
}

