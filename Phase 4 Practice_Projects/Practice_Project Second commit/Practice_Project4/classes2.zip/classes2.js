
class Person {
   
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }

   
    sayHello() {
        console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
    }
}


let person1 = new Person('John', 25);
let person2 = new Person('Jane', 30);


person1.sayHello(); 
person2.sayHello(); 
